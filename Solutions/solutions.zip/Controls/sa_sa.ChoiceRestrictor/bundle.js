/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./ChoiceRestrictor/HelloWorld.tsx":
/*!*****************************************!*\
  !*** ./ChoiceRestrictor/HelloWorld.tsx ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   HelloWorld: () => (/* binding */ HelloWorld)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react */ \"@fluentui/react\");\n/* harmony import */ var _fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__);\n\n\n\n\nvar onRenderCaretDown = () => {\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__.Icon, {\n    iconName: \"CirclePlus\"\n  });\n};\nclass HelloWorld extends react__WEBPACK_IMPORTED_MODULE_0__.Component {\n  constructor(props) {\n    var _a, _b, _c, _d, _e;\n    super(props);\n    this.state = {\n      isMultiSelectOptionSet: props.isMultiSelectOptionSet,\n      Choices: props.Choices,\n      defaultChoice: props.defaultChoice,\n      isDisable: props.isDisable,\n      selectedChoiceSingle: props.selectedChoiceSingle,\n      selectableOptions: (_a = props.Choices) === null || _a === void 0 ? void 0 : _a.filter(option => !(option === null || option === void 0 ? void 0 : option.disabled) && (option === null || option === void 0 ? void 0 : option.key) !== \"selectAll\"),\n      //selectedChoiceMulti: props.selectedChoiceMulti,\n      selectedChoiceMulti: ((_b = props.selectedChoiceMulti) === null || _b === void 0 ? void 0 : _b.filter(key => key.toString() !== 'selectAll').length) >= ((_d = (_c = props.Choices) === null || _c === void 0 ? void 0 : _c.filter(option => !(option === null || option === void 0 ? void 0 : option.disabled) && (option === null || option === void 0 ? void 0 : option.key) !== \"selectAll\")) === null || _d === void 0 ? void 0 : _d.length) ? ['selectAll', ...(((_e = props.selectedChoiceMulti) === null || _e === void 0 ? void 0 : _e.map(o => o)) || [])] : props.selectedChoiceMulti\n    };\n    this.updateValues = this.updateValues.bind(this);\n  }\n  updateValues(event, option) {\n    var _a, _b, _c;\n    var selected = option === null || option === void 0 ? void 0 : option.selected;\n    var currentSelectedOptionKeys = (_a = this.state.selectedChoiceMulti) === null || _a === void 0 ? void 0 : _a.filter(key => {\n      var _a;\n      return key.toString() !== 'selectAll' && !((_a = this.props.restrictedChoices) === null || _a === void 0 ? void 0 : _a.includes(key.toString()));\n    });\n    var selectAllState = (currentSelectedOptionKeys === null || currentSelectedOptionKeys === void 0 ? void 0 : currentSelectedOptionKeys.length) === ((_b = this.state.selectableOptions) === null || _b === void 0 ? void 0 : _b.length);\n    if (this.state.isMultiSelectOptionSet) {\n      if ((option === null || option === void 0 ? void 0 : option.key) === \"selectAll\") {\n        selectAllState ? this.setState(prevState => {\n          this.props.onChange([]);\n          return {\n            selectedChoiceMulti: []\n          };\n        }) : this.setState(prevState => {\n          var _a, _b;\n          this.props.onChange([...(((_a = prevState.selectableOptions) === null || _a === void 0 ? void 0 : _a.map(o => o.key)) || [])]);\n          return {\n            selectedChoiceMulti: ['selectAll', ...(((_b = prevState.selectableOptions) === null || _b === void 0 ? void 0 : _b.map(o => o.key)) || [])]\n          };\n        });\n      } else {\n        if (selected) {\n          this.setState(prevState => {\n            var _a;\n            var updatedChoices = [...(prevState.selectedChoiceMulti || []), option === null || option === void 0 ? void 0 : option.key];\n            this.props.onChange(updatedChoices); // Pass the updated state to onChange\n            if ((updatedChoices === null || updatedChoices === void 0 ? void 0 : updatedChoices.filter(key => {\n              var _a;\n              return key.toString() !== 'selectAll' && !((_a = this.props.restrictedChoices) === null || _a === void 0 ? void 0 : _a.includes(key.toString()));\n            }).length) >= ((_a = this.state.selectableOptions) === null || _a === void 0 ? void 0 : _a.length)) return {\n              selectedChoiceMulti: ['selectAll', ...(updatedChoices.map(o => o) || [])]\n            };else return {\n              selectedChoiceMulti: updatedChoices\n            };\n          });\n        } else {\n          var index = (_c = this.state.selectedChoiceMulti) === null || _c === void 0 ? void 0 : _c.indexOf(option === null || option === void 0 ? void 0 : option.key);\n          if (index !== undefined && index !== -1) {\n            this.setState(prevState => {\n              var _a;\n              // Create a copy of the current array\n              var updatedChoices = [...(prevState.selectedChoiceMulti || [])];\n              // Remove the item at the found index\n              updatedChoices.splice(index, 1);\n              var indexAll = (_a = this.state.selectedChoiceMulti) === null || _a === void 0 ? void 0 : _a.indexOf(\"selectAll\");\n              if (indexAll !== undefined && indexAll !== -1) updatedChoices.splice(indexAll, 1);\n              this.props.onChange(updatedChoices);\n              return {\n                selectedChoiceMulti: updatedChoices\n              };\n            });\n          }\n        }\n      }\n    } else {\n      this.setState({\n        selectedChoiceSingle: option === null || option === void 0 ? void 0 : option.key\n      }, () => {\n        this.props.onChange(option === null || option === void 0 ? void 0 : option.key);\n      });\n    }\n  }\n  render() {\n    var {\n      isMultiSelectOptionSet,\n      Choices,\n      selectedChoiceSingle,\n      selectedChoiceMulti,\n      isDisable\n    } = this.state;\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      className: styles.container\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__.Dropdown, {\n      className: styles.Dropdown,\n      placeholder: \"Select an option\",\n      multiSelect: isMultiSelectOptionSet,\n      options: Choices,\n      onRenderCaretDown: onRenderCaretDown,\n      defaultSelectedKey: selectedChoiceSingle,\n      // Dynamically handle selectedKey vs. selectedKeys\n      selectedKey: isMultiSelectOptionSet ? undefined : selectedChoiceSingle,\n      selectedKeys: isMultiSelectOptionSet ? selectedChoiceMulti : undefined,\n      disabled: isDisable,\n      onChange: this.updateValues\n    }));\n  }\n}\nvar styles = (0,_fluentui_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_1__.mergeStyleSets)({\n  container: {\n    display: 'flex',\n    alignItems: 'baseline',\n    gap: '10px',\n    minWidth: '-webkit-fill-available'\n  },\n  Dropdown: {\n    flexGrow: 1 // Allows DatePicker to take available space\n  }\n});\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ChoiceRestrictor/HelloWorld.tsx?");

/***/ }),

/***/ "./ChoiceRestrictor/index.ts":
/*!***********************************!*\
  !*** ./ChoiceRestrictor/index.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   ChoiceRestrictor: () => (/* binding */ ChoiceRestrictor)\n/* harmony export */ });\n/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @fluentui/react */ \"@fluentui/react\");\n/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _HelloWorld__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./HelloWorld */ \"./ChoiceRestrictor/HelloWorld.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nclass ChoiceRestrictor {\n  constructor() {\n    /**\r\n     * Empty constructor.\r\n     */\n    this._Choices = [];\n    this.onChoiceSelectChange = selectedChoice => {\n      if (this._isMultiSelectOptionSet) {\n        this._selectedChoiceMulti = selectedChoice;\n      } else this._selectedChoiceSingle = selectedChoice;\n      this.notifyOutputChanged();\n    };\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   */\n  init(context, notifyOutputChanged, state) {\n    var _a, _b, _c, _d, _e;\n    this.notifyOutputChanged = notifyOutputChanged;\n    this._restrictedChoices = (_a = context.parameters.RestrictedChoices.raw) === null || _a === void 0 ? void 0 : _a.split(\",\").map(choice => choice.trim());\n    // Cast the attributes to the CustomChoiceAttributes type\n    var attributes = context.parameters.choice.attributes;\n    // Handle DefaultValue\n    if (attributes === null || attributes === void 0 ? void 0 : attributes.DefaultValue) {\n      this._defaultChoice = attributes.DefaultValue;\n    }\n    this._isMultiSelectOptionSet = (attributes === null || attributes === void 0 ? void 0 : attributes.Type) === \"multiselectpicklist\";\n    if (this._isMultiSelectOptionSet) {\n      this._Choices.push({\n        key: 'selectAll',\n        text: 'Select All',\n        itemType: _fluentui_react__WEBPACK_IMPORTED_MODULE_0__.SelectableOptionMenuItemType.SelectAll\n      });\n      this._selectedChoiceMulti = Array.isArray(context.parameters.choice.raw) ? context.parameters.choice.raw : [];\n    } else {\n      if (!(((_b = context.parameters.choice.attributes) === null || _b === void 0 ? void 0 : _b.RequiredLevel) == 1 || ((_c = context.parameters.choice.attributes) === null || _c === void 0 ? void 0 : _c.RequiredLevel) == 2)) this._Choices.push({\n        key: 'Null',\n        text: '--Select--',\n        itemType: _fluentui_react__WEBPACK_IMPORTED_MODULE_0__.SelectableOptionMenuItemType.SelectAll\n      });\n      this._selectedChoiceSingle = (_e = (_d = attributes.Options) === null || _d === void 0 ? void 0 : _d.find(it => {\n        return it.Label === context.parameters.choice.formatted;\n      })) === null || _e === void 0 ? void 0 : _e.Value;\n    }\n    // Handle Options\n    var options = attributes === null || attributes === void 0 ? void 0 : attributes.Options;\n    options === null || options === void 0 ? void 0 : options.forEach(option => {\n      var _a;\n      this._Choices.push({\n        key: option.Value,\n        text: option.Label,\n        disabled: (_a = this._restrictedChoices) === null || _a === void 0 ? void 0 : _a.includes(option.Value.toString())\n      });\n    });\n    this._isDisable = context.mode.isControlDisabled;\n  }\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   * @returns ReactElement root react element for the control\r\n   */\n  updateView(context) {\n    var props = {\n      Choices: this._Choices,\n      defaultChoice: this._defaultChoice,\n      selectedChoiceSingle: this._selectedChoiceSingle,\n      selectedChoiceMulti: this._selectedChoiceMulti,\n      onChange: this.onChoiceSelectChange,\n      isMultiSelectOptionSet: this._isMultiSelectOptionSet,\n      isDisable: this._isDisable,\n      restrictedChoices: this._restrictedChoices\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2__.createElement(_HelloWorld__WEBPACK_IMPORTED_MODULE_1__.HelloWorld, props);\n  }\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\r\n   */\n  getOutputs() {\n    var _a;\n    if (this._isMultiSelectOptionSet) {\n      return {\n        choice: (_a = this._selectedChoiceMulti) !== null && _a !== void 0 ? _a : null\n      };\n    } else {\n      return {\n        choice: typeof this._selectedChoiceSingle === 'number' ? this._selectedChoiceSingle : null\n      };\n    }\n  }\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ChoiceRestrictor/index.ts?");

/***/ }),

/***/ "@fluentui/react":
/*!*************************************!*\
  !*** external "FluentUIReactv8290" ***!
  \*************************************/
/***/ ((module) => {

module.exports = FluentUIReactv8290;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/***/ ((module) => {

module.exports = React;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./ChoiceRestrictor/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('sa.ChoiceRestrictor', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ChoiceRestrictor);
} else {
	var sa = sa || {};
	sa.ChoiceRestrictor = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ChoiceRestrictor;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}